/*
 sygnal dzwiekowy

*/
void beep(int l=10){
      ON(P_BEEPER);
      delay_ms(l);
      OFF(P_BEEPER);
      delay_ms(5);
}

/*
  sprawdzenie jaki przycisk z panelu sterowania jest klik
  domyslny stan pinow na rezystorze podciagajacym:
  E_OK   (E2) - false
  E_DOWN (C0) - true
  E_UP   (C1) - true
  po ich wcisnieciu stan przeciwny do domyslnego, 
  czyli aktywacja sygnalem odwrotnym do domyslnego.
*/
char enterimp = 4;  

int getButton() {
    
    set_adc_channel(1);
    delay_ms(1);
    int8 an=read_ADC();
    delay_ms(3);

    //0
    if (an == 0){
            beep();
            enterimp = 0;
            //printf(lcd_putc,"\f down ");
            delay_ms(1000);
            return E_DOWN;
    } 
    //246
    if (an == 246){
               if (enterimp==3){
                        beep();
                        enterimp = enterimp + 1;
                        //printf(lcd_putc," ok ");
                        delay_ms(1000);
                        return E_OK;        
                }
                if (enterimp < 4){
                        enterimp = enterimp + 1;
                        //printf(lcd_putc," idle ");
                        delay_ms(1000);
                        return E_IDLE;
                }
             return E_IDLE;

    }
    //156
    if (an == 156){
             beep();
             enterimp = 0;
             //printf(lcd_putc,"\f up ");
             delay_ms(1000);
             return E_UP;
    }
    
    return E_IDLE;
    
}

/*
 zmiana stanu
 przekaznika 1 (oswietlenie)

void relay_light()
{
   //jesli wylaczony to wlaczyc
   if (swich1 == 'f')
   {
      ON(P_LIGHT);
      swich1 = 'n';
   }

   //byl wlaczony to wylaczyc
   else
   {
      OFF(P_LIGHT);
      swich1 = 'f';
   }
}
*/

/*
wyswietlenie na ekranie 
informacji o temperaturze
w akwarium
*/
void print_aqua_temp(float t){
   if (t!=111.0){
      lcd_gotoxy(1,2);
      /*
      sprintf(ctemp, "%3.1f", ds1820_read());
      for (x=0; x<4; x++){ 
            lcd_putc(ctemp[x]);
      }*/
      lcd_send_byte(1,0x4); //symbol wody
      printf(lcd_putc, "%3.1f", t); 
      lcd_send_byte(1,0x2); //stopnie celsjusza
   }
   else {
      lcd_gotoxy(1,2);
      printf(lcd_putc, "      "); 
   }
   
   
}



/*
wyswietlenie na ekranie 
informacji o temperaturze
w pomieszczeniu
*/
void print_room_temp(float t){
   lcd_gotoxy(11,2);
   /*
   sprintf(ctemp, "%3.1f", ds1820_read());
   for (x=0; x<4; x++){ 
           lcd_putc(ctemp[x]);
   }*/
   lcd_send_byte(1,0x5); //symbol domku
   printf(lcd_putc, "%3.1f", t); 
   lcd_send_byte(1,0x2); //stopnie celsjusza
   
   
}

void print_time(){
  lcd_gotoxy(8,2);
  lcd_send_byte(1,0x6); //symbol zegarka
  printf(lcd_putc, "%02d:%02d:%02d", hour,min,sec);
}

/*
wyswietlenie na ekranie
funkcji klawiszy przewijania menu
*/
void print_menubar(){
   lcd_gotoxy(1,2);
   lcd_putc("<"); //strzalka w lewo
   lcd_gotoxy(8,2);
   //lcd_putc((char)126); //enter
   lcd_putc("ok");
   lcd_gotoxy(16,2);
   lcd_putc(">"); //strzalka w prawo
}





/*
ustawienie w menu temperatury
*/
void SetTemperature(){
    boolean run=true;
    int8 t;

    t = read_eeprom(0x00);
    //jesli nie jest ustawiona to napewno nie jest 255 stopni ustawienie domyslnej 25 stopni
    if (t == 255) t=25;

    lcd_putc("\f");
    print_menubar();
    delay_ms(800);
    while(run){
        delay_ms(800);
        lcd_gotoxy(2,1);
        printf(lcd_putc, "Utrzymuj %u ", t); 
        lcd_send_byte(1,0x2); //stopnie celsjusza
        
        switch(getButton()){
            case E_DOWN:
                t = t-1;
                break;
            case E_UP:
                t = t+1;
                break;
            case E_OK:
                write_eeprom(0x00,t);
                run=false;
        }
    }

}

/*
ustawianie godziny
*/
int8 menu_hour(int8 h)
{
   boolean run=true;
   lcd_putc("\f");
   print_menubar();
   delay_ms(800);
   //ustawianie godziny
   while(run){
        //delay_ms(800);
        lcd_gotoxy(2,1);
        printf(lcd_putc, "Godzina %02d  ", h); 
        
        switch(getButton()){
            case E_DOWN:
                h = h-1;
                if(h<0 || h==255) h=24;
                break;
            case E_UP:
                h = h+1;
                if(h>24) h=0;
                break;
            case E_OK:                
                run=false;
        }
    }
    return h;
}

/*
ustawianie minut
*/
int8 menu_minute(int8 m)
{
   boolean run=true;
   lcd_putc("\f");
   print_menubar();
   delay_ms(800);
   while(run){
        //delay_ms(800);
        lcd_gotoxy(2,1);
        printf(lcd_putc, "Minuta %02d  ", m); 
        
        switch(getButton()){
            case E_DOWN:
                m = m-1;
                if(m<0 || m==255) m=59;
                break;
            case E_UP:
                m = m+1;
                if(m>59) m=0;
                break;
            case E_OK:                
                run=false;
        }
    }
    return m;
}

/*
ustawianie sekund
*/
int8 menu_sec(int8 s)
{
   boolean run=true;
   lcd_putc("\f");
   print_menubar();
   delay_ms(800);
   while(run){
        //delay_ms(800);
        lcd_gotoxy(2,1);
        printf(lcd_putc, "Sekund %02d  ", s); 
        
        switch(getButton()){
            case E_DOWN:
                s = s-1;
                if(s<0 || s==255) s=59;
                break;
            case E_UP:
                s = s+1;
                if(s>59) s=0;
                break;
            case E_OK:                
                run=false;
        }
    }
    return s;
}

//czytanie zegara
void read_time()
{
   sec = bcdToDec(read_ds1307 (0)); // read second
   min = bcdToDec(read_ds1307 (1)); // read minute
   hour = bcdToDec(read_ds1307 (2)); // read hour
   //day = bcdToDec(read_ds1307 (4)); // read day
   //month = bcdToDec(read_ds1307 (5)); // read month
   //year = bcdToDec(read_ds1307 (6)); // read year
}

//ustawianie zegara
void set_time()
{
   write_ds1307 (4, decToBcd(1)); //day
   write_ds1307 (5, decToBcd(1)); //month
   write_ds1307 (6, decToBcd(0)); //year
   write_ds1307 (2, decToBcd(hour)); //hour;
   write_ds1307 (1, decToBcd(min)); //minute
   write_ds1307 (0, decToBcd(0)); //second

}


/*
obsluga menu
*/
void change_menu(){

    #define MENU_ELEMENTS 7
    
    //przesuniecie sie po menu w gore
    if (menu_event == E_UP && menu_pos < MENU_ELEMENTS && menu_select==false){ menu_pos++;}
    //przesuniecie sie po menu w dol
    if (menu_event == E_DOWN && 0 < menu_pos && menu_select==false){ menu_pos--;}
    //zatwierdzenie opcji w menu
    if (menu_event == E_OK && menu_pos!=0) menu_select = true;

    switch(menu_pos){
        case 0:
            lcd_putc("\fOpusc menu");
            print_menubar();
            delay_ms(1000);
            menu_select=false;
            menu_pos=0;
            lcd_putc("\f");
            break;
        case 1:
            lcd_putc("\fTemperatura");
            print_menubar();
            if (menu_select) {
                SetTemperature();
                beep();
                beep();
                menu_select=false;
                menu_pos=0;
                lcd_putc("\f");
            }
            break;
        case 2:
            lcd_putc("\fWl.oswietlenia");
            print_menubar();
            if (menu_select) {
                write_eeprom(EEPROM_LIGHT_HOUR_ON,menu_hour(read_eeprom(EEPROM_LIGHT_HOUR_ON)));
                write_eeprom(EEPROM_LIGHT_MIN_ON,menu_minute(read_eeprom(EEPROM_LIGHT_MIN_ON)));
                printf(lcd_putc, "\fUstawiono %02d:%02d", read_eeprom(EEPROM_LIGHT_HOUR_ON), read_eeprom(EEPROM_LIGHT_MIN_ON));
                delay_ms(2000);
                beep();
                beep();
                menu_select=false;
                menu_pos=0;
                lcd_putc("\f");
            }
            break;            
        case 3:
            lcd_putc("\fWyl.oswietlenia");
            print_menubar();
            if (menu_select) {
                write_eeprom(EEPROM_LIGHT_HOUR_OFF,menu_hour(read_eeprom(EEPROM_LIGHT_HOUR_OFF)));
                write_eeprom(EEPROM_LIGHT_MIN_OFF,menu_minute(read_eeprom(EEPROM_LIGHT_MIN_OFF)));
                printf(lcd_putc, "\fUstawiono %02d:%02d", read_eeprom(EEPROM_LIGHT_HOUR_OFF), read_eeprom(EEPROM_LIGHT_MIN_OFF));
                delay_ms(2000);
                beep();
                beep();
                menu_select=false;
                menu_pos=0;
                lcd_putc("\f");
            }
            break;
        case 4:
            lcd_putc("\fNapowietrzanie");
            print_menubar();
            if (menu_select) {
                last_air_hour_on = 0;
                write_eeprom(EEPROM_AIR_HOUR_CYCLE,menu_hour(read_eeprom(EEPROM_AIR_HOUR_CYCLE)));
                write_eeprom(EEPROM_AIR_MIN_DELAY,menu_minute(read_eeprom(EEPROM_AIR_MIN_DELAY)));
                printf(lcd_putc, "\fUruchomienie\nco %02d h/%02d min", read_eeprom(EEPROM_AIR_HOUR_CYCLE), read_eeprom(EEPROM_AIR_MIN_DELAY));
                delay_ms(2000);
                beep();
                beep();
                menu_select=false;
                menu_pos=0;
                lcd_putc("\f");
            }
            break;
        case 5:
            lcd_putc("\fKarmienie");
            print_menubar();
            if (menu_select) {
                last_feed_hour_on = 0;
                write_eeprom(EEPROM_FEED_HOUR_CYCLE,menu_hour(read_eeprom(EEPROM_FEED_HOUR_CYCLE)));
                write_eeprom(EEPROM_FEED_SEC_DELAY,menu_sec(read_eeprom(EEPROM_FEED_SEC_DELAY)));
                printf(lcd_putc, "\fUruchomienie\nco %02d h/%02d s", read_eeprom(EEPROM_FEED_HOUR_CYCLE), read_eeprom(EEPROM_FEED_SEC_DELAY));
                delay_ms(2000);
                beep();
                beep();
                menu_select=false;
                menu_pos=0;
                lcd_putc("\f");
            }
            break;
        case 6:
            lcd_putc("\fZegar");
            print_menubar();
            if (menu_select) {
                hour = menu_hour(hour);
                min = menu_minute(min);
                printf(lcd_putc, "\fUstawiono %02d:%02d", hour,min);
                //zapis
                set_time();
                delay_ms(3000);
                beep();
                beep();
                menu_select=false;
                menu_pos=0;
                lcd_putc("\f");
            }
            break; 
         case 7:
            lcd_putc("\fTestuj");
            print_menubar();
            if (menu_select) {
                beep();
                beep();

                   lcd_putc("\ftest:");

                   //lampa
                   lcd_gotoxy(6,1);
                   lcd_send_byte(1,0x0);
                   ON(P_LIGHT);
                   delay_ms(2000);
                   OFF(P_LIGHT);
                   delay_ms(3000);
                   
                   //grzalka
                   lcd_gotoxy(6,1);
                   lcd_send_byte(1,0x1);
                   ON(P_LIGHT);
                   delay_ms(2000);
                   OFF(P_LIGHT);
                   delay_ms(3000);
                
                   //karmienie
                   lcd_gotoxy(6,1);
                   lcd_send_byte(1,0x5);
                   ON(P_FEED);
                   delay_ms(2000);
                   OFF(P_FEED);
                   delay_ms(3000);

                   //napowietrzanie
                   lcd_gotoxy(6,1);
                   lcd_send_byte(1,0x7);
                   ON(P_AIR);
                   delay_ms(2000);
                   OFF(P_AIR);
                   delay_ms(3000);
                
                menu_select=false;
                menu_pos=0;
                beep();
                lcd_putc("\f");
            }
            break;
            
    }
}

/*
 dodaje do hour:min:sec czas podany w sekundach
 i zwraca w tablicy w formacie hour:min:sec
 */
void sum_during(byte hour, byte min, byte sec, byte during, byte t[]){
    //przeliczenie podanego czasu na sekundy
    //int as = (hour * 3600) + (min * 60) + sec;
    int16 as = (hour * 3600) + (min * 60) + sec;
    
    int16 d;
    //int t[2]; //h:m:s
    //dodanie do podanego czasu czasu trwania (during)
    d = as + during;
    //przeliczenie na format czasu
    t[0] =  (byte)(((d / 60) / 60) % 24);
    t[1] =  (byte)((d / 60) % 60);
    t[2] =  (byte)(d % 60);
    printf(lcd_putc,"\f%lu %lu\n",as, d);
    delay_ms(2000);
}

